﻿// keysound.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <io.h>
#include <direct.h>
#include <string>
#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <conio.h>
#include<vector>
#include <comdef.h>
#include <thread>
#include <time.h>
#pragma comment(lib, "winmm.lib")
using namespace std;
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" ) // 设置入口地址



// 静态资源
#define IDI_ICON1 102


// 取随机数
int randEx(int a, int b)
{
	if (a == b)
		return a;
	LARGE_INTEGER seed;
	QueryPerformanceFrequency(&seed);
	QueryPerformanceCounter(&seed);
	srand(seed.QuadPart);
	return rand() % b + a;
}

// 播放音效函数
void playtheSound(string path)
{	
	cout << path << endl;
	string lpath = "open " + path + " alias mysong";

	// 把lpath里的 \ 改成 /
	for (int i = 0; i < lpath.length(); i++)
	{
		if (lpath[i] == '\\')
			lpath[i] = '/';
	}
	cout << "--------------666---" << lpath;
	_bstr_t bstr(lpath.c_str());
	LPTSTR lr = (LPTSTR)bstr;
	// (TEXT("open X:/C++/keysound/x64/Debug/sounds//2.wav alias mysong"), NULL, 0, NULL);
	mciSendString(lr, NULL, 0, NULL);
	mciSendString(TEXT("play MySong"), NULL, 0, NULL);
	return;
}

// 取运行目录
string getRunPath()
{
	char buf[MAX_PATH];
	GetModuleFileNameA(NULL, buf, MAX_PATH);
	string::size_type pos = string(buf).find_last_of("\\/");
	string dir = string(buf).substr(0, pos);
	return dir;
}


// 初始化
void init_res(int a)
{
	string prefix = "./sounds/";
	if (_access(prefix.c_str(), 0) == -1){ // 如果文件夹不存在
		_mkdir(prefix.c_str());							// 则创建
	}
	string aa = "./sounds/random";
	if (_access(aa.c_str(), 0) == -1){ // 如果文件夹不存在
		_mkdir(aa.c_str());							// 则创建
	}
	string b = "./sounds/keyname";
	if (_access(b.c_str(), 0) == -1){ // 如果文件夹不存在
		_mkdir(b.c_str());							// 则创建
	}
	if(a == 1){
		// 打开sounds文件夹
		// 用system打开同级目录下的sounds文件夹
		string dir = getRunPath();
		string cmd = "explorer " + dir + "\\sounds";
		system(cmd.c_str());
	}
	// 最后写入一些自带的基础音效
	// 以后用户可以自定义修改
}

// 文件夹遍历
void getFileNames(string path, vector<string>& files)
{
	//文件句柄
	//注意：我发现有些文章代码此处是long类型，实测运行中会报错访问异常
	intptr_t hFile = 0;
	//文件信息
	struct _finddata_t fileinfo;
	string p;
	if ((hFile = _findfirst(p.assign(path).append("/*").c_str(), &fileinfo)) != -1)
	{
		do
		{
			//如果是目录,递归查找
			//如果不是,把文件绝对路径存入vector中
			if ((fileinfo.attrib & _A_SUBDIR))
			{
				if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
					getFileNames(p.assign(path).append("/").append(fileinfo.name), files);
			}
			else
			{
				files.push_back(p.assign(path).append("/").append(fileinfo.name));
			}
		} while (_findnext(hFile, &fileinfo) == 0);
		_findclose(hFile);
	}
}


HHOOK keyboardHook = 0; // 钩子句柄
// 按键变量
string key = "";
string prefix = "/sounds/keyname/";
// 模式flag 0是播放按钮名.wav 1是随机播放
int flag = 1;
LRESULT CALLBACK LowLevelKeyboardProc(
		_In_ int nCode,			// 规定钩子如何处理消息，小于 0 则直接 CallNextHookEx
		_In_ WPARAM wParam, // 消息类型
		_In_ LPARAM lParam	// 指向某个结构体的指针，这里是 KBDLLHOOKSTRUCT（低级键盘输入事件）
)
{
	KBDLLHOOKSTRUCT *ks = (KBDLLHOOKSTRUCT *)lParam; // 包含低级键盘输入事件信息
	/*
	typedef struct tagKBDLLHOOKSTRUCT {
		DWORD     vkCode;		// 按键代号
		DWORD     scanCode;		// 硬件扫描代号，同 vkCode 也可以作为按键的代号。sad
		DWORD     flags;		// 事件类型，一般按键按下为 0 抬起为 128。
		DWORD     time;			// 消息时间戳
		ULONG_PTR dwExtraInfo;	// 消息附加信息，一般为 0。
	}KBDLLHOOKSTRUCT,*LPKBDLLHOOKSTRUCT,*PKBDLLHOOKSTRUCT;
	*/
	// if (ks->flags == 128 || ks->flags == 129)
	cout << "flags: " << ks->flags << endl;
	if (ks->flags == 0)
	{
		if (flag == 0)
		{
			cout << "按键--9999--：" << ks->vkCode << endl;
			// 监控键盘
			switch (ks->vkCode)
			{
			case 0x30:
			case 0x60:
				cout << "检测到按键："
						 << "0" << endl;
				key = "0";
				break;
			case 0x31:
			case 0x61:
				cout << "检测到按键："
						 << "1" << endl;
				key = "1";
				break;
			case 0x32:
			case 0x62:
				cout << "检测到按键："
						 << "2" << endl;
				key = "2";
				break;
			case 0x33:
			case 0x63:
				cout << "检测到按键："
						 << "3" << endl;
				key = "3";
				break;
			case 0x34:
			case 0x64:
				cout << "检测到按键："
						 << "4" << endl;
				key = "4";
				break;
			case 0x35:
			case 0x65:
				cout << "检测到按键："
						 << "5" << endl;
				key = "5";
				break;
			case 0x36:
			case 0x66:
				cout << "检测到按键："
						 << "6" << endl;
				key = "6";
				break;
			case 0x37:
			case 0x67:
				cout << "检测到按键："
						 << "7" << endl;
				key = "7";
				break;
			case 0x38:
			case 0x68:
				cout << "检测到按键："
						 << "8" << endl;
				key = "8";
				break;
			case 0x39:
			case 0x69:
				cout << "检测到按键："
						 << "9" << endl;
				key = "9";
				break;
			case 0x41:
				cout << "检测到按键："
						 << "A" << endl;
				key = "A";
				break;
			case 0x42:
				cout << "检测到按键："
						 << "B" << endl;
				key = "B";
				break;
			case 0x43:
				cout << "检测到按键："
						 << "C" << endl;
				key = "C";
				break;
			case 0x44:
				cout << "检测到按键："
						 << "D" << endl;
				key = "D";
				break;
			case 0x45:
				cout << "检测到按键："
						 << "E" << endl;
				key = "E";
				break;
			case 0x46:
				cout << "检测到按键："
						 << "F" << endl;
				key = "F";
				break;
			case 0x47:
				cout << "检测到按键："
						 << "G" << endl;
				key = "G";
				break;
			case 0x48:
				cout << "检测到按键："
						 << "H" << endl;
				key = "H";
				break;
			case 0x49:
				cout << "检测到按键："
						 << "I" << endl;
				key = "I";
				break;
			case 0x4A:
				cout << "检测到按键："
						 << "J" << endl;
				key = "J";
				break;
			case 0x4B:
				cout << "检测到按键："
						 << "K" << endl;
				key = "K";
				break;
			case 0x4C:
				cout << "检测到按键："
						 << "L" << endl;
				key = "L";
				break;
			case 0x4D:
				cout << "检测到按键："
						 << "M" << endl;
				key = "M";
				break;
			case 0x4E:
				cout << "检测到按键："
						 << "N" << endl;
				key = "N";
				break;
			case 0x4F:
				cout << "检测到按键："
						 << "O" << endl;
				key = "O";
				break;
			case 0x50:
				cout << "检测到按键："
						 << "P" << endl;
				key = "P";
				break;
			case 0x51:
				cout << "检测到按键："
						 << "Q" << endl;
				key = "Q";
				break;
			case 0x52:
				cout << "检测到按键："
						 << "R" << endl;
				key = "R";
				break;
			case 0x53:
				cout << "检测到按键："
						 << "S" << endl;
				key = "S";
				break;
			case 0x54:
				cout << "检测到按键："
						 << "T" << endl;
				key = "T";
				break;
			case 0x55:
				cout << "检测到按键："
						 << "U" << endl;
				key = "U";
				break;
			case 0x56:
				cout << "检测到按键："
						 << "V" << endl;
				key = "V";
				break;
			case 0x57:
				cout << "检测到按键："
						 << "W" << endl;
				key = "W";
				break;
			case 0x58:
				cout << "检测到按键："
						 << "X" << endl;
				key = "X";
				break;
			case 0x59:
				cout << "检测到按键："
						 << "Y" << endl;
				key = "Y";
				break;
			case 0x5A:
				cout << "检测到按键："
						 << "Z" << endl;
				key = "Z";
				break;
			case 0x6A:
				cout << "检测到按键："
						 << "*" << endl;
				key = "*";
				break;
			case 0x6B:
				cout << "检测到按键："
						 << "+" << endl;
				key = "+";
				break;
			case 0x6D:
				cout << "检测到按键："
						 << "-" << endl;
				key = "-";
				break;
			case 0x6E:
				cout << "检测到按键："
						 << "." << endl;
				key = ".";
				break;
			case 0x6F:
				cout << "检测到按键："
						 << "/" << endl;
				key = "/";
				break;
			case 0x0D:
				cout << "检测到按键："
						 << "Enter" << endl;
				key = "Enter";
				break;
			case 0xA0:
			case 0xA1:
				cout << "检测到按键："
						 << "Shift" << endl;
				key = "Shift";
				break;
			case 0x08:
				cout << "检测到按键："
						 << "Backspace" << endl;
				key = "Backspace";
				break;
			case 0x20:
				cout << "检测到按键："
						 << "Space" << endl;
				key = "Space";
				break;
			case 162:
				cout << "检测到按键："
						 << "Ctrl" << endl;
				key = "Ctrl";
				break;
			}


			string path = prefix + key + ".wav";
			// 播放key.wav音效
			// cout << "播放音效" << path;
			// 取运行目录
			string dir = getRunPath();
			// 拼接音效文件路径
			path = dir + path;
			cout << "播放音效" << path + "\n";
			// 播放音效
			thread t1(playtheSound, path);
			// 线程分离
			t1.detach();
		}
		else if (flag == 1)
		{
			// 拿到sounds文件夹下的所有文件
			vector<string> fileNames;
			string path("./sounds/random");
			getFileNames(path, fileNames);
			// 如果fileNames为空，直接返回
			if (fileNames.empty())
			{
				return CallNextHookEx(NULL, nCode, wParam, lParam);
			}
			// 随机抽取容器中的一个文件名
			int index = randEx(0, fileNames.size() - 1);
			// 取运行目录
			string dir = getRunPath();
			string path_ = dir + fileNames[index].substr(1, dir.size() - 1);
			// 创建线程
			thread t1(playtheSound, path_);
			// 线程分离
			t1.detach();
		}
	}

	// 将消息传递给钩子链中的下一个钩子
	return CallNextHookEx(NULL, nCode, wParam, lParam);
}

// 键盘hook
int key_hook()
{
	// 安装钩子
	keyboardHook = SetWindowsHookEx(
			WH_KEYBOARD_LL,					// 钩子类型，WH_KEYBOARD_LL 为键盘钩子
			LowLevelKeyboardProc,		// 指向钩子函数的指针
			GetModuleHandleA(NULL), // Dll 句柄
			NULL);

	if (keyboardHook == 0)
	{
		cout << "挂钩键盘失败" << endl;
		return -1;
	}

	// 不可漏掉消息处理，不然程序会卡死
	MSG msg;
	while (1)
	{
		// 如果消息队列中有消息
		if (PeekMessageA(
						&msg,			// MSG 接收这个消息
						NULL,			// 检测消息的窗口句柄，NULL：检索当前线程所有窗口消息
						NULL,			// 检查消息范围中第一个消息的值，NULL：检查所有消息（必须和下面的同时为NULL）
						NULL,			// 检查消息范围中最后一个消息的值，NULL：检查所有消息（必须和上面的同时为NULL）
						PM_REMOVE // 处理消息的方式，PM_REMOVE：处理后将消息从队列中删除
						))
		{
			// 把按键消息传递给字符消息
			TranslateMessage(&msg);

			// 将消息分派给窗口程序
			DispatchMessageW(&msg);
		}
		else
			Sleep(0); // 避免CPU全负载运行
	}
	// 删除钩子
	UnhookWindowsHookEx(keyboardHook);
	return 0;
}



#define IDR_PAUSE 12
#define IDR_START 13
#define IDR_TEST 14
#define IDR_OPENDIR 18
// 菜单常量
#define IDR_QUIT 15
#define IDR_RANDOM 16
#define IDR_KETNAME 17
LPCTSTR szAppClassName = TEXT("keysound");
LPCTSTR szAppWindowName = TEXT("keysound");
HMENU hmenu;//菜单句柄

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    NOTIFYICONDATA nid;
    UINT WM_TASKBARCREATED;
    POINT pt;//用于接收鼠标坐标
    int xx;//用于接收菜单选项返回值

    // 不要修改TaskbarCreated，这是系统任务栏自定义的消息
    WM_TASKBARCREATED = RegisterWindowMessage(TEXT("TaskbarCreated"));
    switch (message)
    {
    case WM_CREATE://窗口创建时候的消息.
        nid.cbSize = sizeof(nid);
        nid.hWnd = hwnd;
        nid.uID = 0;
        nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
        nid.uCallbackMessage = WM_USER;
        nid.hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1));
        lstrcpy(nid.szTip, szAppClassName);
        Shell_NotifyIcon(NIM_ADD, &nid);
        hmenu = CreatePopupMenu();//生成菜单
				AppendMenu(hmenu, MF_CHECKED, IDR_RANDOM, L"随机模式");
				AppendMenu(hmenu, MF_UNCHECKED, IDR_KETNAME, L"键名模式");
				AppendMenu(hmenu, MF_STRING, IDR_OPENDIR, L"打开目录");
				AppendMenu(hmenu, MF_STRING, IDR_AUTORUN, L"开机自启");
				AppendMenu(hmenu, MF_STRING, IDR_QUIT, L"退出");
        break;
    case WM_USER://连续使用该程序时候的消息.
        if (lParam == WM_RBUTTONDOWN)
        {
            GetCursorPos(&pt);//取鼠标坐标
            ::SetForegroundWindow(hwnd);//解决在菜单外单击左键菜单不消失的问题
            // EnableMenuItem(hmenu, IDR_PAUSE, MF_GRAYED);//让菜单中的某一项变灰
            xx = TrackPopupMenu(hmenu, TPM_RETURNCMD, pt.x, pt.y, NULL, hwnd, NULL);//显示菜单并获取选项ID
						if (xx == IDR_QUIT){
								// 移除托盘图标
								 // 卸载托盘图标
								NOTIFYICONDATA nid;
								nid.cbSize = sizeof(NOTIFYICONDATA);
								nid.hWnd = hwnd;
								nid.uID = 0;
								Shell_NotifyIcon(NIM_DELETE, &nid);
								// 退出程序
								PostQuitMessage(0);
						}
						if (xx == IDR_RANDOM){
								// 选中随机模式 取消键名模式
								flag = 1;
								CheckMenuItem(hmenu, IDR_RANDOM, MF_CHECKED);
								CheckMenuItem(hmenu, IDR_KETNAME, MF_UNCHECKED);

						}
						if (xx == IDR_KETNAME){
								// 选中键名模式 取消随机模式
								flag = 0;
								CheckMenuItem(hmenu, IDR_RANDOM, MF_UNCHECKED);
								CheckMenuItem(hmenu, IDR_KETNAME, MF_CHECKED);
						}
						if (xx == IDR_OPENDIR){
								// 打开目录
								init_res(1);
						}
        }
        break;
    case WM_DESTROY://窗口销毁时候的消息.
        Shell_NotifyIcon(NIM_DELETE, &nid);
        PostQuitMessage(0);
        break;
    default:
        /*
        * 防止当Explorer.exe 崩溃以后，程序在系统系统托盘中的图标就消失
        *
        * 原理：Explorer.exe 重新载入后会重建系统任务栏。当系统任务栏建立的时候会向系统内所有
        * 注册接收TaskbarCreated 消息的顶级窗口发送一条消息，我们只需要捕捉这个消息，并重建系
        * 统托盘的图标即可。
        */
        if (message == WM_TASKBARCREATED)
            SendMessage(hwnd, WM_CREATE, wParam, lParam);
        break;
    }
    return DefWindowProc(hwnd, message, wParam, lParam);
}



// 设置右下角图标
int SetIco() 
{
    
    HWND hwnd;
    MSG msg;
    WNDCLASS wndclass;

    HWND handle = FindWindow(NULL, szAppWindowName);
    // if (handle != NULL)
    // {
    //     MessageBox(NULL, TEXT("Application is already running"), szAppClassName, MB_ICONERROR);
    //     return 0;
    // }

    wndclass.style = CS_HREDRAW | CS_VREDRAW;
    wndclass.lpfnWndProc = WndProc;
    wndclass.cbClsExtra = 0;
    wndclass.cbWndExtra = 0;
    wndclass.hInstance = NULL;
    wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
    wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
    wndclass.lpszMenuName = NULL;
    wndclass.lpszClassName = szAppClassName;

    if (!RegisterClass(&wndclass))
    {
        MessageBox(NULL, TEXT("This program requires Windows NT!"), szAppClassName, MB_ICONERROR);
        return 0;
    }

    // 此处使用WS_EX_TOOLWINDOW 属性来隐藏显示在任务栏上的窗口程序按钮
    hwnd = CreateWindowEx(WS_EX_TOOLWINDOW,
        szAppClassName, szAppWindowName,
        WS_POPUP,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL, NULL, NULL, NULL);

    ShowWindow(hwnd, 0);
    UpdateWindow(hwnd);

    //消息循环
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}



int main()
{
	// 初始化函数 创建sounds文件夹 并写入基础音效 后续用户可以自定义修改
	init_res(0);
	// 开线程去keyhook
	thread t2(key_hook);
	// 线程分离
	t2.detach();
	SetIco();
}
